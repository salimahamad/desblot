<?php include 'header.php'; ?>
  <section class="py-4 pt-5 mt-5">
   <div class="container">
    <div class="contactContainer">
      <div class="row align-items-center">
        <div class="col-md-5 text-center text-md-start">
            <h1>Contacto</h1>
            <p><strong>correo electrónico de :</strong> <a href="mailto:support@desblot.com">support@desblot.com</a></p> 
            <p>desblot se pondrá en contacto en 24/48 horas</p>

            <a href="mailto:support@desblot.com" class="btn btn-primary rounded-pill btn-lg px-4 mt-4">Enviar mensaje</a>
        </div>
        <div class="col-md-7">
          <img src="assets/img/contactus.png" class="img-fluid"/>
        </div>
       
      </div>
    </div>
   </div>
 </section>
<?php include 'footer.php'; ?>