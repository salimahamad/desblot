
    <footer>
      <div class="container">
        <a href="index.php">Home </a> | <a href="contact.php">  Contacto </a> | <a href="trems.php">Terminos y condiciones</a> | <a href="privacy.php">Privacidad</a>
        <div class="mt-2">© 2024 Desblot. All rights reserved.</div>
      </div>
    </footer>

    <div class="showLatestBuoght">
      <div class="card">
        <div class="card-body">
          <div class="d-flex gap-3">
            <div>
              <img src="assets/img/argentina.png" class="" height="40" />
            </div>
            <div>
              <p><strong>Nicolas</strong>  (Argentina, Buenos Aires)</p>
              <p>Unlocked Bouygues <strong>iPhone 12</strong> </p>
              <div class="mt-2"><small  class="d-flex align-items-center"> En este momento -  <span class="text-success d-inline-flex align-items-center"><span class="material-symbols-outlined"> check_circle </span> Verificado</span> </small> </div>
            </div>
          </div>
        </div>
      </div>
    </div>

   
    <!-- typed -->
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.11"> </script>
    <!-- slick -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="assets/js/custom.js"></script>
  </body>
</html>